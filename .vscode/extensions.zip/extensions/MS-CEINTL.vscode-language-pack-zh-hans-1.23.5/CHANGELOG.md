# Change Log
All notable changes to the "vscode-language-pack-zh-hans" language pack will be documented in this file.

## [Released]
May 5, 2018 - Release for VS Code 1.23
April 16, 2018 - Initial release
